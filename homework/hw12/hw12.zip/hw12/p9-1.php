<?php

$a = $_POST["t1"];
$b = $_POST["t2"];
$c = $a + $b;

echo "總和為".$c;
?>